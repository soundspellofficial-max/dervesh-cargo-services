## Transport Management System
## update

 Provide transportation solution for your business need.


<div class="jumbotron">
  <h1> Record Daily Transportation Activity</h1>
  <p>Make Entry of Challen(Shippment), Add Vehicle Infomation and Customer Details</p>
</div>

<div class="section" id="install">
    <h2>Install</h2>

    ##From your site

    To install this app, login to your site and click on "Installer". Search for <b>Transport Management System</b> and click on "Install"

    ##Using Bench

    Go to your bench folder and setup the new app

    $ bench get-app transport_management_system https://github.com/vishdha/transport_management_system
    $ bench --site testsite install-app transport_management_system
</div>

<div class="section">
    <h2>Author</h2>

    Vishal Dhayagude (vishaldhayagude07@gmail.com)
</div>


#### License

MIT
