// Copyright (c) 2016, Vishal Dhayagude and contributors
// For license information, please see license.txt

frappe.ui.form.on('Location', {
	refresh: function(frm) {

	}
});
