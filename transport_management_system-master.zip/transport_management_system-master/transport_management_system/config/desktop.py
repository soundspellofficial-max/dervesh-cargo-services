# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from frappe import _

def get_data():
	return [
		{
			"module_name": "Transport Management System",
			"color": "blue",
			"icon": "fa fa-truck",
			"type": "module",
			"label": _("Transport Management System")
		}
	]
