Freight Management System
==========================

This application allows you to manage Truckload Freights and Less-than-truckload freight. It also can help Companies such as owner-operators, carriers, brokers and shippers.

It handles full Travel workflow:

Transport Requirement => Waybill => Freight => Delivery

Managing:
- Driver Cash advance (Payment & Conciliation)
- Fuel Voucher Management
- Checking Travel Expenses
- Freight Invoicing (Trucks of the company or third parties)

It also can manage:
- Trucks Red Tapes
- Truck Odometers
- Events during travel (Example: Arrival delay, Missing Cargo, etc)
- Kits
- Places (Linked with Google Maps)
- Routes (Visible in Google Maps)
- Easy integration with GPS System
